﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myapp
{
    public class GPIOState
    {
        public bool led1 { get; set; }
        public bool sw1 { get; set; }
    }
}
